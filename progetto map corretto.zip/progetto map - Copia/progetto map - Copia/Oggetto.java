public class Oggetto {
    private String nome;
    private String descrizione; 
    private boolean raccoglibile; 
    
    public Oggetto(String nome, String descrizione, boolean raccoglibile){
        this.nome = nome; 
        this.descrizione = descrizione; 
        this.raccoglibile = raccoglibile; 
    }
    
    public String getNome() {
        return nome; 
    }
    public String getDescrizione() {
        return descrizione; 
    }
    public boolean getRaccoglibile() {
        return raccoglibile; 
    }
    
    @Override
    public String toString() {
        return nome; 
    }
}