import java.sql.*;
import java.util.*;

public class DatabaseManager {
    private static final String URL = "jdbc:sqlite:salvataggi.db";

    public static void inizializzaDatabase() {
        try {
            // Forza il caricamento del driver JDBC
            Class.forName("org.sqlite.JDBC"); 
            String sqlCreaTabella = "CREATE TABLE IF NOT EXISTS partite (" +
         "nome_slot TEXT PRIMARY KEY, ossigeno INTEGER, stanza TEXT, " +
         "difficolta TEXT, sala_motori BOOLEAN, schema_controllo BOOLEAN, " +
         "turni_siero INTEGER, cavo_collegato BOOLEAN, inventario TEXT, enigmi TEXT, " +
         "condotto_sbloccato BOOLEAN);";

            try (Connection conn = DriverManager.getConnection(URL);
                 Statement stmt = conn.createStatement()) {
                stmt.execute(sqlCreaTabella);
            }
        } catch (Exception e) {
            System.err.println("ERRORE CRITICO DB (Manca il file .jar di SQLite?): " + e.getMessage());
        }
    }

    public static boolean salvaPartita(Gioco gioco, String nomeSlot) {
        inizializzaDatabase(); // Assicuriamoci che la tabella esista sempre!
       String sql = "INSERT OR REPLACE INTO partite (nome_slot, ossigeno, stanza, difficolta, " +
        "sala_motori, schema_controllo, turni_siero, cavo_collegato, inventario, enigmi, " +
        "condotto_sbloccato) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, nomeSlot);
            pstmt.setInt(2, gioco.getOssigeno());
            pstmt.setString(3, gioco.getGiocatore().getStanzaCorrente().getNome());
            pstmt.setString(4, gioco.getDifficolta());
            pstmt.setBoolean(5, gioco.isSalaMotoriRiparata());
            pstmt.setBoolean(6, gioco.isHaSchemaDiControllo());
            pstmt.setInt(7, gioco.getTurniSieroAttivi());
            pstmt.setBoolean(8, gioco.isCavoCollegato());
            
            StringBuilder inv = new StringBuilder();
            for (Oggetto o : gioco.getGiocatore().getInventario()) {
                if (inv.length() > 0) inv.append("|");
                inv.append(o.getNome());
            }
            pstmt.setString(9, inv.toString());
            
            StringBuilder enigmi = new StringBuilder();
            for (String s : gioco.getEnigmiRisolti()) {
                if (enigmi.length() > 0) enigmi.append("|");
                enigmi.append(s);
            }
            pstmt.setString(10, enigmi.toString());

            pstmt.setString(10, enigmi.toString());
            pstmt.setBoolean(11, gioco.isCondottoSbloccato());
            
            pstmt.executeUpdate();
            return true;
        } catch (Exception e) {
            System.err.println("ERRORE SALVATAGGIO: " + e.getMessage());
            return false;
        }
    }

    public static List<String> elencaSlot() {
        inizializzaDatabase();
        List<String> slots = new ArrayList<>();
        String sql = "SELECT nome_slot FROM partite";
        try (Connection conn = DriverManager.getConnection(URL);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                slots.add(rs.getString("nome_slot"));
            }
        } catch (Exception e) {}
        return slots;
    }

    public static Map<String, String> caricaPartita(String nomeSlot) {
        String sql = "SELECT * FROM partite WHERE nome_slot = ?";
        Map<String, String> dati = new HashMap<>();
        try (Connection conn = DriverManager.getConnection(URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, nomeSlot);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                dati.put("ossigeno", String.valueOf(rs.getInt("ossigeno")));
                dati.put("stanza", rs.getString("stanza"));
                dati.put("difficolta", rs.getString("difficolta"));
                dati.put("salaMotoriRiparata", String.valueOf(rs.getBoolean("sala_motori")));
                dati.put("haSchemaDiControllo", String.valueOf(rs.getBoolean("schema_controllo")));
                dati.put("turniSiero", String.valueOf(rs.getInt("turni_siero")));
                dati.put("cavoCollegato", String.valueOf(rs.getBoolean("cavo_collegato")));
                dati.put("inventario", rs.getString("inventario"));
                dati.put("enigmiRisolti", rs.getString("enigmi"));
            }
        } catch (Exception e) {
            return null;
        }
        return dati;
    }
}