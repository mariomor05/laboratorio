import java.util.*;

public class Gioco {

    private Giocatore giocatore;
    private int ossigeno;
    private boolean salaMotoriRiparata;
    private boolean haSchemaDiControllo;
    private boolean vinto;
    private final Set<String> enigmiRisolti = new HashSet<>();

    private Stanza cabina, corridoio, infermeria, salaMotori,
                   laboratorio, corridoioAllagato, deposito, camera, condottoAerazione;

    private int turniSieroAttivi = 0;
    private boolean cavoCollegato = false;
    private String difficolta = "Normale"; // Default impostato dallo stile originale
    private boolean condottoSbloccato = false; 

    public Gioco() {
        this("Normale");
    }

    public Gioco(String difficolta) {
        this.difficolta = difficolta;
        this.ossigeno = 100;
        this.salaMotoriRiparata = false;
        this.haSchemaDiControllo = false;
        this.vinto = false;
        costruisciMappa();
    }

    // -------------------------------------------------------
    // CARICAMENTO DA DATABASE / MAPPA
    // -------------------------------------------------------
    public String caricaDaFile(Map<String, String> dati) {
        try {
            ossigeno            = Integer.parseInt(dati.getOrDefault("ossigeno", "100"));
            difficolta          = dati.getOrDefault("difficolta", "Normale");
            salaMotoriRiparata  = Boolean.parseBoolean(dati.getOrDefault("salaMotoriRiparata","false"));
            haSchemaDiControllo = Boolean.parseBoolean(dati.getOrDefault("haSchemaDiControllo","false"));
            turniSieroAttivi    = Integer.parseInt(dati.getOrDefault("turniSiero","0"));
            cavoCollegato       = Boolean.parseBoolean(dati.getOrDefault("cavoCollegato","false"));
            condottoSbloccato   = Boolean.parseBoolean(dati.getOrDefault("condottoSbloccato","false"));

            if (condottoSbloccato) {
                laboratorio.setUscita("NORD", condottoAerazione);
            }

            String enigmiStr = dati.getOrDefault("enigmiRisolti","");
            enigmiRisolti.clear();
            if (!enigmiStr.isEmpty())
                for (String s : enigmiStr.split("\\|")) enigmiRisolti.add(s);

            String nomeStanza = dati.getOrDefault("stanza","Corridoio Allagato");
            Stanza stanzaRip = trovaStan(nomeStanza);
            if (stanzaRip == null) stanzaRip = corridoioAllagato;

            List<Oggetto> nuovoInv = new ArrayList<>();
            String invStr = dati.getOrDefault("inventario","");
            if (!invStr.isEmpty()) {
                for (String nomeOgg : invStr.split("\\|")) {
                    Oggetto trovato = trovaOggettoInMappa(nomeOgg);
                    if (trovato != null) {
                        rimuovaDaStanze(trovato);
                        nuovoInv.add(trovato);
                    } else {
                        nuovoInv.add(oggettoEnigmaPerNome(nomeOgg));
                    }
                }
            }

            giocatore = new Giocatore(stanzaRip);
            for (Oggetto o : nuovoInv) giocatore.aggiungiOggetto(o, null);

            return "Partita caricata. Sei in: " + stanzaRip.getNome();
        } catch (Exception e) {
            return "Errore nel caricamento: " + e.getMessage();
        }
    }

    private Stanza trovaStan(String nome) {
        for (Stanza s : tutteLeStanze())
            if (s.getNome().equalsIgnoreCase(nome)) return s;
        return null;
    }
    private Oggetto trovaOggettoInMappa(String nome) {
        for (Stanza s : tutteLeStanze())
            for (Oggetto o : s.getOggetto())
                if (o.getNome().equalsIgnoreCase(nome)) return o;
        return null;
    }
    private void rimuovaDaStanze(Oggetto o) {
        for (Stanza s : tutteLeStanze()) s.removeOggetto(o);
    }
    private Stanza[] tutteLeStanze() {
        return new Stanza[]{cabina,corridoio,infermeria,salaMotori,
                            laboratorio,corridoioAllagato,deposito,camera,condottoAerazione};
    }

    private Oggetto oggettoEnigmaPerNome(String nome) {
        switch (nome) {
            case "Generatore di Riserva":
                return new Oggetto(nome,"Un piccolo generatore. Ancora funzionante.\nCollegandolo all'impianto guadagni ossigeno.",true);
            case "Siero Stabilizzante":
                return new Oggetto(nome,"Una fiala trasparente etichettata 'O2-STAB'.\nStabilizza il consumo di ossigeno temporaneamente.",true);
            case "Benda Energetica":
                return new Oggetto(nome,"Una benda ad alta resistenza.\nSul foglietto: 'Per ferite gravi e domande filosofiche irrisolvibili.'",true);
            case "Cavo Rinforzato":
                return new Oggetto(nome,"Un cavo da 2000 volt ancora intatto.\nPotrebbe servire nella sala motori.",true);
            case "Manuale Tecnico":
                return new Oggetto(nome,
                    "Un manuale di emergency.\n" +
                    "Sequenza riparazione motore:\n" +
                    "1. Inserire batteria\n" +
                    "2. Collegare cavo rinforzato\n" +
                    "3. Attivare pannello di alimentazione.",true);
            case "Torcia Elettrica":
                return new Oggetto(nome, "Fa luce. Molto utile nei posti bui del sottomarino.", true);
            case "Tessera Magnetica":
                return new Oggetto(nome, "Una tessera di livello 1. Serve per sbloccare i condotti.", true);
            case "Filtro d'Aria":
                return new Oggetto(nome, "Un filtro intatto. Sostituendolo purifichi completamente l'aria.", true);
            default:
                return new Oggetto(nome,"Oggetto recuperato.",true);
        }
    }

    // -------------------------------------------------------
    // ENIGMI
    // -------------------------------------------------------
    public boolean stanzaHaEnigma(String nomeStanza) {
        return switch (nomeStanza) {
            case "Cabina di Comando","Laboratorio Biologico",
                 "Infermeria","Deposito Tecnico","Sala Motori" -> true;
            default -> false;
        };
    }

    public boolean enigmaGiaRisolto(String nomeStanza) {
        return enigmiRisolti.contains(nomeStanza);
    }

    public String risolviEnigma(String stanza, String risposta) {
        if (enigmiRisolti.contains(stanza))
            return "Hai gia' risolto l'enigma di questa stanza.";

        consuma(3);

        switch (stanza) {
            case "Cabina di Comando":
                if (risposta.trim().equals("21")) {
                    enigmiRisolti.add(stanza);
                    Oggetto generatore = new Oggetto(
                        "Generatore di Riserva",
                        "Un piccolo generatore. Ancora funzionante.\n" +
                        "Collegandolo all'impianto guadagni ossigeno.", true);
                    giocatore.getStanzaCorrente().addOggetto(generatore);
                    ossigeno = Math.min(100, ossigeno + 10);
                    return "SEQUENZA CORRETTA.\nIl sistema si sblocca.\n" +
                           "Trovi un generatore di riserva.\nOssigeno al " + ossigeno + "%.";
                }
                return "SEQUENZA ERRATA. Il pannello non risponde.";

            case "Laboratorio Biologico":
                if (risposta.trim().equals("77")) {
                    enigmiRisolti.add(stanza);
                    Oggetto siero = new Oggetto(
                        "Siero Stabilizzante",
                        "Una fiala trasparente etichettata 'O2-STAB'.\n" +
                        "Stabilizza il consumo di ossigeno temporaneamente.", true);
                    giocatore.getStanzaCorrente().addOggetto(siero);
                    return "CODICE CORRETTO.\nIl pannello del laboratorio si apre.\n" +
                           "Trovi un siero stabilizzante.";
                }
                return "CODICE ERRATO. Il monitor torna in standby.";

            case "Infermeria":
                if (risposta.trim().equals("20")) {
                    enigmiRisolti.add(stanza);
                    Oggetto benda = new Oggetto(
                        "Benda Energetica",
                        "Una benda ad alta resistenza.\n" +
                        "Sul foglietto: 'Per ferite gravi e domande filosofiche irrisolvibili.'", true);
                    giocatore.getStanzaCorrente().addOggetto(benda);
                    return "RISPOSTA CORRETTA.\nUn cassetto nascosto si apre sotto il lettino.\n" +
                           "Trovi una benda energetica.";
                }
                return "RISPOSTA ERRATA. Il cassetto rimane chiuso.";

            case "Deposito Tecnico":
                if (risposta.trim().equals("56")) {
                    enigmiRisolti.add(stanza);
                    Oggetto cavo = new Oggetto(
                        "Cavo Rinforzato",
                        "Un cavo da 2000 volt ancora intatto.\n" +
                        "Potrebbe servire nella sala motori.", true);
                    giocatore.getStanzaCorrente().addOggetto(cavo);
                    return "SERRATURA APERTA.\nLa cassa cede con uno scatto metallico.\n" +
                           "Trovi un cavo rinforzato.";
                }
                return "CODICE ERRATO. La serratura non cede.";

            case "Sala Motori":
                if (risposta.trim().equals("-1")) {
                    enigmiRisolti.add(stanza);
                    Oggetto manuale = new Oggetto(
                        "Manuale Tecnico",
                        "Un manuale di emergenza.\n" +
                        "Sequenza riparazione motore:\n" +
                        "1. Inserire batteria\n" +
                        "2. Collegare cavo rinforzato\n" +
                        "3. Attivare pannello di alimentazione.", true);
                    giocatore.getStanzaCorrente().addOggetto(manuale);
                    return "RISPOSTA CORRETTA.\nUn pannello laterale si apre.\n" +
                           "Trovi il manuale tecnico del sottomarino.";
                }
                return "RISPOSTA ERRATA. Il pannello rimane bloccato.";

            default:
                return "Non c'e' nessun enigma in questa stanza.";
        }
    }

    public String usaSieroStabilizzante() {
        if (!giocatore.haOggetto("Siero Stabilizzante"))
            return "Non hai il siero stabilizzante.";
        turniSieroAttivi = 3;
        Iterator<Oggetto> iter = giocatore.getInventario().iterator();
        while (iter.hasNext()) {
            if (iter.next().getNome().equalsIgnoreCase("Siero Stabilizzante")) {
                iter.remove(); break;
            }
        }
        return "Inietti il siero.\nSenti i polmoni stabilizzarsi.\n" +
               "L'ossigeno non diminuira' per i prossimi 3 movimenti.";
    }

    // -------------------------------------------------------
    // COSTRUZIONE MAPPA
    // -------------------------------------------------------
    private void costruisciMappa() {
        cabina            = new Stanza("Cabina di Comando",
            "Schermi rotti emettono una luce fioca. Il pannello mostra:\n" +
            "- Propulsione OFFLINE\n- Pressione esterna CRITICA\n- Sistema di emersione NON FUNZIONANTE");
        corridoio         = new Stanza("Corridoio Centrale",
            "Il corridoio percorre l'intera spina dorsale del sottomarino.\n" +
            "Cavi scoperti e luci al neon ad intermittenza.");
        infermeria        = new Stanza("Infermeria",
            "Scaffali aperti di fretta. Foglietti per terra, lettino sporco di sangue.\n" +
            "Una bombola di ossigeno d'emergenza e' ancora intatta.");
        salaMotori        = new Stanza("Sala Motori",
            "Enormi macchinari ridotti a ferraglia. Cavi pendono dal soffitto.\n" +
            "Scintille illuminano la stanza. C'e' uno spazio vuoto per la batteria.");
        laboratorio       = new Stanza("Laboratorio Biologico",
            "Becher e provette galleggiano nell'acqua salata.\n" +
            "Vasche con forme di vita sconosciute. Un armadietto corroso...");
        corridoioAllagato = new Stanza("Corridoio Allagato",
            "L'acqua arriva alle ginocchia. Ogni passo e' uno sforzo.\n" +
            "La pressione nelle orecchie aumenta.");
        deposito          = new Stanza("Deposito Tecnico",
            "Scaffali metallici, bulloni e cavi sul pavimento.\n" +
            "Aria di plastica bruciata. Una cassa di emergenza socchiusa.");
        camera            = new Stanza("Camera di Decompressione",
            "Pareti di acciaio con rivetti. Una grande porta ermetica.");
        
        // NUOVA STANZA AGGIUNTA
        condottoAerazione = new Stanza("Condotto di Aerazione",
            "Un cunicolo buio e claustrofobico sopra le nostre teste. Senti un forte odore di gas.");

        cabina.setUscita("SUD", corridoio);
        corridoio.setUscita("NORD", cabina);
        corridoio.setUscita("OVEST", infermeria);
        corridoio.setUscita("EST", laboratorio);
        corridoio.setUscita("SUD", salaMotori);
        infermeria.setUscita("EST", corridoio);
        salaMotori.setUscita("NORD", corridoio);
        salaMotori.setUscita("SUD", corridoioAllagato);
        laboratorio.setUscita("OVEST", corridoio);
        corridoioAllagato.setUscita("NORD", salaMotori);
        corridoioAllagato.setUscita("SUD", camera);
        corridoioAllagato.setUscita("EST", deposito);
        deposito.setUscita("OVEST", corridoioAllagato);
        camera.setUscita("NORD", corridoioAllagato);
        
        // Collegamento bidirezionale condotto (attivato tramite Tessera Magnetica)
        condottoAerazione.setUscita("SUD", laboratorio);

        infermeria.addOggetto(new Oggetto("Bombola Ossigeno",
            "Una bombola d'emergenza ancora intatta. +15% ossigeno.", true));
        infermeria.addOggetto(new Oggetto("Kit Medico",
            "Una cassetta di pronto soccorso.", true));
        laboratorio.addOggetto(new Oggetto("Scheda di Controllo",
            "Una scheda elettronica fondamentale per il sistema di emersione.", true));
        laboratorio.addOggetto(new Oggetto("Campione Biologico",
            "Un campione strano nelle vasche. Meglio non toccarlo.", false));
        deposito.addOggetto(new Oggetto("Batteria",
            "BATTERIA AUSILIARIA - USARE SOLO IN CASO DI AVARIA. Pesante ma funzionante.", true));
        deposito.addOggetto(new Oggetto("Attrezzi",
            "Cacciaviti e chiavi inglesi sparsi.", true));
            
        // Oggetto nascosto nella nuova stanza
        condottoAerazione.addOggetto(new Oggetto("Filtro d'Aria", 
            "Un filtro intatto. Sostituendolo purifichi completamente l'aria.", true));

        giocatore = new Giocatore(corridoioAllagato);

        // OGGETTI INVENTARIO INIZIALE RICHIESTI
        giocatore.aggiungiOggetto(new Oggetto("Torcia Elettrica", "Fa luce. Molto utile nei posti bui del sottomarino.", true), null);
        giocatore.aggiungiOggetto(new Oggetto("Tessera Magnetica", "Una tessera di livello 1. Serve per sbloccare i condotti.", true), null);
    }

    // -------------------------------------------------------
    // AZIONI OGGETTI NUOVI
    // -------------------------------------------------------
    public String usaTorcia() {
        if (!giocatore.getStanzaCorrente().getNome().equalsIgnoreCase("Condotto di Aerazione"))
            return "Accendi la torcia, ma in questa stanza c'e' gia' luce a sufficienza.";
        return "Illumini il condotto! Noti qualcosa di metallico incastrato sul fondo: un Filtro d'Aria.";
    }

    public String usaTesseraMagnetica() {
        if (!giocatore.getStanzaCorrente().getNome().equalsIgnoreCase("Laboratorio Biologico"))
            return "Passi la tessera sulle pareti, ma non trovi nessun lettore magnetico.";
        condottoSbloccato = true;
        laboratorio.setUscita("NORD", condottoAerazione);
        return "BIP! Un servo-motore scatta. La grata sul soffitto si sblocca! Aperta l'uscita a NORD.";
    }

    public String usaFiltro() {
        if (!giocatore.haOggetto("Filtro d'Aria"))
            return "Non possiedi nessun filtro d'aria.";
        ossigeno = 100;
        rimuoviSeMonouso("Filtro d'Aria");
        return "Sostituisci il filtro intasato con quello nuovo. L'aria torna fresca! Ossigeno al 100%.";
    }

    // -------------------------------------------------------
    // AZIONI VECCHIE
    // -------------------------------------------------------
    public String muovi(String direzione) {
        if (turniSieroAttivi > 0) turniSieroAttivi--;
        else consuma(3);
        boolean ok = giocatore.muovi(direzione);
        if (!ok) return "Non puoi andare in quella direzione.";
        return "Sei entrato in: " + giocatore.getStanzaCorrente().getNome();
    }

    public String prendiOggetto(Oggetto o) {
        if (!o.getRaccoglibile())
            return "Non puoi raccogliere " + o.getNome() + ".";
        giocatore.getStanzaCorrente().removeOggetto(o);
        giocatore.aggiungiOggetto(o, null);
        return "Hai raccolto: " + o.getNome();
    }

    public String esamina(Oggetto o) {
        return o.getDescrizione();
    }

    public void rimuoviSeMonouso(String nomeOggetto) {
        Set<String> riutilizzabili = Set.of("Attrezzi", "Manuale Tecnico", "Torcia Elettrica", "Tessera Magnetica");
        if (riutilizzabili.contains(nomeOggetto)) return;
        Iterator<Oggetto> iter = giocatore.getInventario().iterator();
        while (iter.hasNext()) {
            if (iter.next().getNome().equalsIgnoreCase(nomeOggetto)) {
                iter.remove(); return;
            }
        }
    }

    public String usaCavoRinforzato() {
        if (!giocatore.getStanzaCorrente().getNome().equals("Sala Motori"))
            return "Devi essere nella Sala Motori per collegare il cavo.";
        if (!giocatore.haOggetto("Cavo Rinforzato"))
            return "Non hai il cavo rinforzato nell'inventario.";
        cavoCollegato = true;
        consuma(5);
        rimuoviSeMonouso("Cavo Rinforzato");
        return "Hai collegato il cavo rinforzato! L'impianto elettrico risponde.";
    }

    public String usaBatteria() {
        if (!giocatore.getStanzaCorrente().getNome().equals("Sala Motori"))
            return "Devi essere nella Sala Motori per usare la batteria.";
        if (!giocatore.haOggetto("Batteria"))
            return "Non hai la batteria nell'inventario.";
        if (!cavoCollegato) // CORRETTO ERRORE DI SINTASSI DEL VECCHIO FILE
            return "Prima devi collegare il cavo rinforzato!";
        salaMotoriRiparata = true;
        consuma(5);
        rimuoviSeMonouso("Batteria");
        return "Hai installato la batteria! Il motore comincia a ronzare.\nSala Motori RIPARATA!";
    }

  public String usaScheda() {
        if (!giocatore.getStanzaCorrente().getNome().equals("Cabina di Comando"))
            return "Devi essere nella Cabina di Comando.";
        if (!giocatore.haOggetto("Scheda di Controllo"))
            return "Non hai la scheda di controllo.";
        
//attiva la console solo una volta ed evita lo spreco d'ossigeno
        if(!haSchemaDiControllo) {
            haSchemaDiControllo = true;
            consuma(5);
        }

        
        // SE I MOTORI SONO RIPARATI, VINCI IL GIOCO!
        if (salaMotoriRiparata) {
            rimuoviSeMonouso("Scheda di Controllo"); //consuma solo ora
            return comandoEmersione(); 
        }
        
        return "Scheda inserita. Il sistema risponde... Console ATTIVATA.\nTuttavia non c'e' energia: i motori sono ancora in avaria!";
    }

    public String usaBombolaOssigeno() {
        if (!giocatore.haOggetto("Bombola Ossigeno"))
            return "Non hai la bombola dell'ossigeno.";
        ossigeno = Math.min(100, ossigeno + 15);
        rimuoviSeMonouso("Bombola Ossigeno");
        return "Hai usato la bombola. Ossigeno al " + ossigeno + "%.";
    }

    public String comandoEmersione() {
        if (!giocatore.getStanzaCorrente().getNome().equals("Cabina di Comando"))
            return "Devi essere nella Cabina di Comando.";
        if (!salaMotoriRiparata)
            return "La sala motori non e' ancora riparata!";
        if (!haSchemaDiControllo)
            return "Devi prima inserire la scheda di controllo!";
        vinto = true;
        return "EMERSIONE AVVIATA!\nIl sottomarino comincia a salire verso la superficie...\n" +
               "Congratulazioni! Sei sopravvissuto!";
    }

    public String leggiManuale() {
        if (!giocatore.haOggetto("Manuale Tecnico"))
            return "Non hai il manuale tecnico.";
        return "Un manuale di emergenza.\n" +
               "Sequenza riparazione motore:\n" +
               "1. Inserire batteria\n" +
               "2. Collegare cavo rinforzato\n" +
               "3. Attivare pannello di alimentazione.";
    }

    private void consuma(int quantita) {
        ossigeno = Math.max(0, ossigeno - quantita);
    }

    public void aggiungiOssigeno(int quantita) {
        ossigeno = Math.max(0, Math.min(100, ossigeno + quantita));
    }

    public int getOssigeno()               { return ossigeno; }
    public boolean isVinto()               { return vinto; }
    public boolean isGameOver()            { return ossigeno <= 0; }
    public Giocatore getGiocatore()        { return giocatore; }
    public boolean isSalaMotoriRiparata()  { return salaMotoriRiparata; }
    public boolean isHaSchemaDiControllo() { return haSchemaDiControllo; }
    public int getTurniSieroAttivi()       { return turniSieroAttivi; }
    public Set<String> getEnigmiRisolti()  { return enigmiRisolti; }
    public boolean isCavoCollegato()       { return cavoCollegato; }
    public boolean isCondottoSbloccato()   { return condottoSbloccato; }
    public String getDifficolta()          { return difficolta; }
}