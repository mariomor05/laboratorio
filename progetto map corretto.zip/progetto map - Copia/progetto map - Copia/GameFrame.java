import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.util.*;
import java.util.List;

public class GameFrame extends JFrame {

    private Gioco gioco;
    private Thread threadOssigeno;
    private volatile boolean giocoAttivo = true;

    private JButton btnEnigma;
    private JTextArea areaDescrizione;
    private JList<Oggetto> listaStanza;
    private JList<Oggetto> listaInventario;
    private DefaultListModel<Oggetto> modelStanza;
    private DefaultListModel<Oggetto> modelInventario;
    private JProgressBar barraOssigeno;
    private JLabel labelStanza;
    private PannelloMappa pannelloMappa;

    private JButton btnNord, btnSud, btnEst, btnOvest;
    private JButton btnPrendi, btnEsamina, btnUsa;
    private JButton btnSalva, btnCarica, btnNuovaPartita;

    private static final Color C_BG        = new Color(8, 10, 18);
    private static final Color C_PANEL     = new Color(14, 18, 30);
    private static final Color C_BORDER    = new Color(0, 100, 140);
    private static final Color C_TEXT_GRN  = new Color(0, 220, 100);
    private static final Color C_TEXT_CYAN = new Color(0, 200, 220);
    private static final Color C_TEXT_DIM  = new Color(140, 200, 160);
    private static final Color C_BTN_BG    = new Color(20, 30, 50);
    private static final Color C_BTN_HOV   = new Color(0, 60, 90);
    private static final Color C_RED       = new Color(220, 50, 50);
    private static final Color C_YELLOW    = new Color(220, 200, 0);
    private static final Color C_MAP_BOX   = new Color(16, 22, 38);

    public GameFrame(Gioco istanzaGioco) {
        this.gioco = istanzaGioco;
        inizializzaUI();
        avviaThreadOssigeno();
        
        aggiornaSchermata(
            "Ti svegli di colpo. Il metallo gelido ti brucia la pelle.\n" +
            "Una voce robotica risuona:\nEMERGENZA. OSSIGENO AL 100%.\n" +
            "SISTEMA DI EMERSIONE DANNEGGIATO. EQUIPAGGIO ASSENTE.\n" +
            "Modalita' temporizzata attiva [" + gioco.getDifficolta() + "]\n\n" +
            gioco.getGiocatore().getStanzaCorrente().getDescrizione()
        );
    }

    private void avviaThreadOssigeno() {
        int intervalloMs = switch (gioco.getDifficolta()) {
            case "Facile" -> 10000;
            case "Difficile" -> 3000;
            default -> 6000; // Normale
        };

        threadOssigeno = new Thread(() -> {
            while (giocoAttivo && !gioco.isGameOver() && !gioco.isVinto()) {
                try {
                    Thread.sleep(intervalloMs);
                    
                    if (gioco.getTurniSieroAttivi() <= 0) {
                        gioco.aggiungiOssigeno(-1);
                    }
                    
                    SwingUtilities.invokeLater(() -> {
                        aggiornaListeEBarra();
                        if (gioco.isGameOver()) {
                            giocoAttivo = false;
                            JOptionPane.showMessageDialog(this, "L'ossigeno e' esaurito.\nHai perso.", "GAME OVER", JOptionPane.ERROR_MESSAGE);
                            new MenuIniziale();
                            this.dispose();
                        }
                    });
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        });
        threadOssigeno.start();
    }

    private void inizializzaUI() {
        setTitle("PROFONDITA' 3000 — DEATH OR ESCAPE");
        setSize(1320, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(6, 6));
        getContentPane().setBackground(C_BG);

        add(creaPannelloNord(),    BorderLayout.NORTH);
        add(creaAreaDescrizione(), BorderLayout.CENTER);
        add(creaPannelloEst(),     BorderLayout.EAST);
        add(creaPannelloSud(),     BorderLayout.SOUTH);

        pannelloMappa = new PannelloMappa(gioco.getGiocatore().getStanzaCorrente().getNome());
        pannelloMappa.setPreferredSize(new Dimension(310, 0));
        pannelloMappa.setBackground(C_MAP_BOX);
        pannelloMappa.setBorder(titledBorder("MAPPA"));
        add(pannelloMappa, BorderLayout.WEST);

        collegaEventi();
        setLocationRelativeTo(null);
        setVisible(true);
        aggiornaListeEBarra();
    }

    private JPanel creaPannelloNord() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(C_BG);
        p.setBorder(BorderFactory.createEmptyBorder(6, 12, 4, 12));

        labelStanza = new JLabel("CORRIDOIO ALLAGATO");
        labelStanza.setForeground(C_RED);
        labelStanza.setFont(new Font("Monospaced", Font.BOLD, 17));

        JLabel lO2 = new JLabel("O²  ");
        lO2.setForeground(C_TEXT_CYAN);
        lO2.setFont(new Font("Monospaced", Font.BOLD, 13));

        barraOssigeno = new JProgressBar(0, 100);
        barraOssigeno.setValue(100);
        barraOssigeno.setStringPainted(true);
        barraOssigeno.setString("100%");
        barraOssigeno.setForeground(C_TEXT_GRN);
        barraOssigeno.setBackground(new Color(20, 30, 20));
        barraOssigeno.setFont(new Font("Monospaced", Font.BOLD, 11));
        barraOssigeno.setPreferredSize(new Dimension(240, 22));

        btnSalva        = creaPulsante("SALVA",  C_TEXT_GRN);
        btnCarica       = creaPulsante("CARICA", C_TEXT_CYAN);
        btnNuovaPartita = creaPulsante("NUOVA",  C_RED);
        btnSalva.setPreferredSize(new Dimension(82, 28));
        btnCarica.setPreferredSize(new Dimension(82, 28));
        btnNuovaPartita.setPreferredSize(new Dimension(82, 28));

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        right.setBackground(C_BG);
        right.add(lO2); right.add(barraOssigeno);
        right.add(Box.createHorizontalStrut(12));
        right.add(btnNuovaPartita); right.add(btnCarica); right.add(btnSalva);

        p.add(labelStanza, BorderLayout.WEST);
        p.add(right, BorderLayout.EAST);
        return p;
    }

    private JScrollPane creaAreaDescrizione() {
        areaDescrizione = new JTextArea();
        areaDescrizione.setEditable(false);
        areaDescrizione.setBackground(C_BG);
        areaDescrizione.setForeground(C_TEXT_GRN);
        areaDescrizione.setFont(new Font("Monospaced", Font.PLAIN, 13));
        areaDescrizione.setLineWrap(true);
        areaDescrizione.setWrapStyleWord(true);
        areaDescrizione.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
        areaDescrizione.setCaretColor(C_TEXT_GRN);
        JScrollPane sc = new JScrollPane(areaDescrizione);
        sc.setBorder(BorderFactory.createLineBorder(C_BORDER, 1));
        sc.setBackground(C_BG);
        sc.getViewport().setBackground(C_BG);
        return sc;
    }

    private JPanel creaPannelloEst() {
        JPanel p = new JPanel(new GridLayout(2, 1, 0, 6));
        p.setBackground(C_BG);
        p.setPreferredSize(new Dimension(240, 0));
        p.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 6));

        modelStanza = new DefaultListModel<>();
        listaStanza = new JList<>(modelStanza);
        stilizzaLista(listaStanza);
        JScrollPane scS = new JScrollPane(listaStanza);
        scS.setBackground(C_PANEL); scS.getViewport().setBackground(C_PANEL);
        scS.setBorder(titledBorder("OGGETTI NELLA STANZA"));

        modelInventario = new DefaultListModel<>();
        listaInventario = new JList<>(modelInventario);
        stilizzaLista(listaInventario);
        JScrollPane scI = new JScrollPane(listaInventario);
        scI.setBackground(C_PANEL); scI.getViewport().setBackground(C_PANEL);
        scI.setBorder(titledBorder("INVENTARIO"));

        p.add(scS); p.add(scI);
        return p;
    }

    private JPanel creaPannelloSud() {
        JPanel p = new JPanel(new BorderLayout(10, 0));
        p.setBackground(C_BG);
        p.setBorder(BorderFactory.createEmptyBorder(4, 12, 10, 12));

        btnNord  = creaPulsante("▲ NORD",  C_TEXT_GRN);
        btnSud   = creaPulsante("▼ SUD",   C_TEXT_GRN);
        btnEst   = creaPulsante("▶ EST",   C_TEXT_GRN);
        btnOvest = creaPulsante("◀ OVEST", C_TEXT_GRN);

        JPanel croce = new JPanel(new GridBagLayout());
        croce.setBackground(C_BG);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(3, 3, 3, 3);
        gbc.gridx = 1; gbc.gridy = 0; croce.add(btnNord,  gbc);
        gbc.gridx = 0; gbc.gridy = 1; croce.add(btnOvest, gbc);
        gbc.gridx = 2; gbc.gridy = 1; croce.add(btnEst,   gbc);
        gbc.gridx = 1; gbc.gridy = 2; croce.add(btnSud,   gbc);

        btnPrendi  = creaPulsante("PRENDI",  C_TEXT_GRN);
        btnEsamina = creaPulsante("ESAMINA", C_TEXT_CYAN);
        btnUsa     = creaPulsante("USA",     C_TEXT_GRN);
        btnEnigma  = creaPulsante("ENIGMA",  C_YELLOW);
        btnEnigma.setBorder(BorderFactory.createLineBorder(C_YELLOW, 1));

        JPanel azioni = new JPanel(new GridLayout(4, 1, 5, 5));
        azioni.setBackground(C_BG);
        azioni.add(btnPrendi); azioni.add(btnEsamina);
        azioni.add(btnUsa);    azioni.add(btnEnigma);

        p.add(croce,  BorderLayout.WEST);
        p.add(azioni, BorderLayout.EAST);
        return p;
    }

    private void collegaEventi() {
        btnNord.addActionListener(e  -> muovi("NORD"));
        btnSud.addActionListener(e   -> muovi("SUD"));
        btnEst.addActionListener(e   -> muovi("EST"));
        btnOvest.addActionListener(e -> muovi("OVEST"));

        btnEnigma.addActionListener(e -> {
            String stanza = gioco.getGiocatore().getStanzaCorrente().getNome();
            String domanda = testoEnigma(stanza);
            String risposta = JOptionPane.showInputDialog(this, domanda, "ENIGMA", JOptionPane.QUESTION_MESSAGE);
            if (risposta != null && !risposta.trim().isEmpty())
                aggiornaSchermata(gioco.risolviEnigma(stanza, risposta));
        });

        btnPrendi.addActionListener(e -> {
            Oggetto sel = listaStanza.getSelectedValue();
            if (sel == null) { aggiornaSchermata("Seleziona un oggetto dalla stanza."); return; }
            if (!sel.getRaccoglibile()) { aggiornaSchermata(sel.getNome() + " non puo' essere raccolta."); return; }
            aggiornaSchermata(gioco.prendiOggetto(sel));
        });

        btnEsamina.addActionListener(e -> {
            Oggetto selS = listaStanza.getSelectedValue();
            Oggetto selI = listaInventario.getSelectedValue();
            Oggetto sel  = (selS != null) ? selS : selI;
            if (sel == null) { aggiornaSchermata("Seleziona un oggetto da esaminare."); return; }
            aggiornaSchermata(gioco.esamina(sel));
        });

        btnUsa.addActionListener(e -> {
            Oggetto sel = listaInventario.getSelectedValue();
            if (sel == null) { aggiornaSchermata("Seleziona un oggetto dall'inventario."); return; }
            aggiornaSchermata(usaOggetto(sel));
        });

        // AGGIORNATO CON JDBC DATABASE MANAGER
        btnSalva.addActionListener(e -> {
            List<String> slots = DatabaseManager.elencaSlot();
            JTextField campoNome = new JTextField(16);
            campoNome.setBackground(C_PANEL);
            campoNome.setForeground(C_TEXT_GRN);
            campoNome.setFont(new Font("Monospaced", Font.PLAIN, 12));
            campoNome.setCaretColor(C_TEXT_GRN);

            JPanel dlg = new JPanel(new BorderLayout(5, 5));
            dlg.setBackground(C_BG);
            JLabel lbl = new JLabel("Nome salvataggio:");
            lbl.setForeground(C_TEXT_CYAN);
            lbl.setFont(new Font("Monospaced", Font.BOLD, 12));
            dlg.add(lbl, BorderLayout.NORTH);
            dlg.add(campoNome, BorderLayout.CENTER);

            if (!slots.isEmpty()) {
                JLabel lbl2 = new JLabel("Slot esistenti (click per selezionare):");
                lbl2.setForeground(C_TEXT_DIM);
                lbl2.setFont(new Font("Monospaced", Font.PLAIN, 11));
                DefaultListModel<String> mdl = new DefaultListModel<>();
                slots.forEach(mdl::addElement);
                JList<String> listaSlot = new JList<>(mdl);
                listaSlot.setBackground(C_PANEL);
                listaSlot.setForeground(C_TEXT_GRN);
                listaSlot.setFont(new Font("Monospaced", Font.PLAIN, 11));
                listaSlot.setSelectionBackground(C_BTN_HOV);
                listaSlot.setSelectionForeground(Color.WHITE);
                listaSlot.addListSelectionListener(ev -> campoNome.setText(listaSlot.getSelectedValue()));
                JScrollPane sc = new JScrollPane(listaSlot);
                sc.setPreferredSize(new Dimension(200, 80));
                JPanel bot = new JPanel(new BorderLayout(3,3));
                bot.setBackground(C_BG);
                bot.add(lbl2, BorderLayout.NORTH);
                bot.add(sc, BorderLayout.CENTER);
                dlg.add(bot, BorderLayout.SOUTH);
            }

            int r = JOptionPane.showConfirmDialog(this, dlg, "SALVA PARTITA", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
            if (r != JOptionPane.OK_OPTION) return;
            String nome = campoNome.getText().trim();
            if (nome.isEmpty()) { aggiornaSchermata("Nome non valido."); return; }
            boolean ok = DatabaseManager.salvaPartita(gioco, nome);
            aggiornaSchermata(ok ? "Partita salvata nel Database: " + nome : "Errore durante il salvataggio.");
        });

        // AGGIORNATO CON JDBC DATABASE MANAGER
        btnCarica.addActionListener(e -> {
            List<String> slots = DatabaseManager.elencaSlot();
            if (slots.isEmpty()) { aggiornaSchermata("Nessun salvataggio trovato."); return; }
            String[] arr = slots.toArray(new String[0]);
            String scelta = (String) JOptionPane.showInputDialog(this, "Scegli la partita da caricare:", "CARICA PARTITA", JOptionPane.PLAIN_MESSAGE, null, arr, arr[0]);
            if (scelta == null) return;
            Map<String,String> dati = DatabaseManager.caricaPartita(scelta);
            if (dati == null) { aggiornaSchermata("Errore nel caricamento."); return; }
           giocoAttivo = false;
            if (threadOssigeno != null) threadOssigeno.interrupt();
            gioco = new Gioco(dati.getOrDefault("difficolta", "Normale"));
            String msg = gioco.caricaDaFile(dati);
            giocoAttivo = true;
            avviaThreadOssigeno();
            aggiornaSchermata(msg + "\n\n" + gioco.getGiocatore().getStanzaCorrente().getDescrizione());
        });
        

        btnNuovaPartita.addActionListener(e -> {
            int r = JOptionPane.showConfirmDialog(this, "Iniziare una nuova partita?\nIl progresso corrente andrà perso.", "NUOVA PARTITA", JOptionPane.YES_NO_OPTION);
            if (r == JOptionPane.YES_OPTION) {
                giocoAttivo = false;
                new MenuIniziale();
                this.dispose();
            }
        });
    }

    private String usaOggetto(Oggetto o) {
        String risultato;
        switch (o.getNome()) {
            case "Batteria":            risultato = gioco.usaBatteria(); break;
            case "Scheda di Controllo": risultato = gioco.usaScheda(); break; // CORRETTO QUI
            case "Bombola Ossigeno":    risultato = gioco.usaBombolaOssigeno(); break;
            case "Siero Stabilizzante": risultato = gioco.usaSieroStabilizzante(); break;
            case "Manuale Tecnico":     risultato = gioco.leggiManuale(); break;
            case "Console di emersione": risultato = gioco.comandoEmersione(); break;
            case "Cavo Rinforzato":     risultato = gioco.usaCavoRinforzato(); break;
            
            case "Torcia Elettrica":    risultato = gioco.usaTorcia(); break;
            case "Tessera Magnetica":   risultato = gioco.usaTesseraMagnetica(); break;
            case "Filtro d'Aria":       risultato = gioco.usaFiltro(); break;
            
            case "Kit Medico":
                risultato = "Ti fasci qualche ferita. Ti senti leggermente meglio.";
                gioco.rimuoviSeMonouso(o.getNome()); // CORRETTO QUI (mancava la 'o' finale)
                break;
            case "Attrezzi":
                risultato = "Potrebbero tornare utili, ma non sai dove usarli adesso.";
                break;
            default:
                risultato = "Non puoi usare " + o.getNome() + " qui.";
        }
        return risultato;
    }
    private void muovi(String direzione) {
        String msg   = gioco.muovi(direzione);
        String descr = gioco.getGiocatore().getStanzaCorrente().getDescrizione();
        aggiornaSchermata(msg + "\n\n" + descr);
    }

    private void aggiornaSchermata(String messaggio) {
        areaDescrizione.setText(messaggio);
        areaDescrizione.setCaretPosition(0);
        aggiornaListeEBarra();
        aggiornaBottoniMovimento();
        aggiornaBottoneEnigma();
        pannelloMappa.aggiornaStanzaCorrente(gioco.getGiocatore().getStanzaCorrente().getNome());

        if(giocoAttivo && gioco.isGameOver()) {
            giocoAttivo = false; 
            JOptionPane.showMessageDialog(this, "L'ossigeno e' esaurito.\nHai perso.", "GAME OVER", JOptionPane.ERROR_MESSAGE);
            new MenuIniziale();
            this.dispose();
        }else if (giocoAttivo && gioco.isVinto()) {
            giocoAttivo = false; 
            JOptionPane.showMessageDialog(this, "Hai riparato i motori e attivato il comando di emersione!\nSei riuscito a fuggire e vincere il gioco!", "CONGRATULAZIONI", JOptionPane.INFORMATION_MESSAGE);
            new MenuIniziale();
            this.dispose();
        }
    }

    private void aggiornaListeEBarra() {
        modelStanza.clear();
        for (Oggetto o : gioco.getGiocatore().getStanzaCorrente().getOggetto())
            modelStanza.addElement(o);
        modelInventario.clear();
        for (Oggetto o : gioco.getGiocatore().getInventario())
            modelInventario.addElement(o);

        int o2 = gioco.getOssigeno();
        barraOssigeno.setValue(o2);
        barraOssigeno.setString(o2 + "%");
        if      (o2 > 50) barraOssigeno.setForeground(C_TEXT_GRN);
        else if (o2 > 20) barraOssigeno.setForeground(new Color(220, 160, 0));
        else              barraOssigeno.setForeground(C_RED);

        labelStanza.setText(gioco.getGiocatore().getStanzaCorrente().getNome().toUpperCase());
    }

    private void aggiornaBottoniMovimento() {
        HashMap<String,Stanza> uscite = gioco.getGiocatore().getStanzaCorrente().getUscite(null);
        btnNord.setEnabled(uscite.containsKey("NORD"));
        btnSud.setEnabled(uscite.containsKey("SUD"));
        btnEst.setEnabled(uscite.containsKey("EST"));
        btnOvest.setEnabled(uscite.containsKey("OVEST"));
    }

    private void aggiornaBottoneEnigma() {
        String stanza = gioco.getGiocatore().getStanzaCorrente().getNome();
        boolean haEnigma = gioco.stanzaHaEnigma(stanza) && !gioco.enigmaGiaRisolto(stanza);
        btnEnigma.setVisible(haEnigma);
    }

    private JButton creaPulsante(String testo, Color fg) {
        JButton btn = new JButton(testo);
        btn.setBackground(C_BTN_BG);
        btn.setForeground(fg);
        btn.setFont(new Font("Monospaced", Font.BOLD, 12));
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createLineBorder(C_BORDER, 1));
        btn.setPreferredSize(new Dimension(100, 36));
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) { btn.setBackground(C_BTN_HOV); }
            public void mouseExited(java.awt.event.MouseEvent e) { btn.setBackground(C_BTN_BG); }
        });
        return btn;
    }

    private void stilizzaLista(JList<Oggetto> lista) {
        lista.setBackground(C_PANEL);
        lista.setForeground(C_TEXT_GRN);
        lista.setFont(new Font("Monospaced", Font.PLAIN, 12));
        lista.setSelectionBackground(C_BTN_HOV);
        lista.setSelectionForeground(Color.WHITE);
        lista.setBorder(BorderFactory.createEmptyBorder(4, 6, 4, 6));
    }

    private TitledBorder titledBorder(String titolo) {
        return BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(C_BORDER, 1),
            titolo, TitledBorder.LEFT, TitledBorder.TOP,
            new Font("Monospaced", Font.BOLD, 11), C_TEXT_CYAN);
    }

    private String testoEnigma(String stanza) {
        return switch (stanza) {
            case "Cabina di Comando" -> "Sul pannello appare una sequenza:\n\n  1, 1, 2, 3, 5, 8, 13, __\n\nInserisci il numero mancante:";
            case "Laboratorio Biologico" -> "Sul monitor appare:\n\n  CONVERTI IN DECIMALE: 01001101\n\nInserisci il risultato:";
            case "Infermeria" -> "Sul muro e' inciso:\n\n  Ho 40 anni, mio figlio ne ha 10.\n  Tra quanti anni mio figlio avra'\n  la meta' dei miei anni?\n\nInserisci la risposta:";
            case "Deposito Tecnico" -> "Sulla cassa e' incisa la sequenza:\n\n  2, 6, 12, 20, 30, 42, __\n\nInserisci il numero mancante:";
            case "Sala Motori" -> "Sul pannello e' scritto:\n\n  Sono un numero.\n  Moltiplicato per me stesso: 1\n  Sommato a me stesso: numero negativo\n\n  Chi sono?";
            default -> "";
        };
    }

    // -------------------------------------------------------
    // PANNELLO MAPPA — INTEGRATA LA NUOVA STANZA
    // -------------------------------------------------------
    private class PannelloMappa extends JPanel {

        private String stanzaCorrente;

        private static final Color M_BOX_NRM  = new Color(18, 26, 46);
        private static final Color M_BOX_CUR  = new Color(0,  70,  40);
        private static final Color M_BRD_NRM  = new Color(30, 80, 110);
        private static final Color M_BRD_CUR  = new Color(0, 210,  90);
        private static final Color M_TXT_NRM  = new Color(140, 190, 200);
        private static final Color M_TXT_CUR  = new Color(0,  230, 100);
        private static final Color M_LINE     = new Color(0,  80, 110);
        private static final Color M_DOT      = new Color(0,  255, 100);
        private static final Color M_ENIGMA   = new Color(200, 180, 0);

        private static final int W  = 148;
        private static final int H  = 44;
        private static final int WS = 98;

        private static final int CX = 78;
        private static final int LX = 4;
        private static final int RX = 162;

        // AGGIUNTA NONA STANZA ALL'INDICE 8
        private final int[][] coord = {
            {CX,  14, W,  H},   // 0  Cabina di Comando
            {CX,  88, W,  H},   // 1  Corridoio Centrale
            {LX, 162, WS, H},   // 2  Infermeria
            {CX, 162, W,  H},   // 3  Sala Motori
            {RX,  88, WS, H},   // 4  Laboratorio Biologico
            {CX, 236, W,  H},   // 5  Corridoio Allagato
            {RX, 236, WS, H},   // 6  Deposito Tecnico
            {CX, 310, W,  H},   // 7  Camera di Decompressione
            {RX,  14, WS, H},   // 8  Condotto di Aerazione (SOPRA IL LAB)
        };

        private final String[] nomi = {
            "CABINA DI\nCOMANDO", "CORRIDOIO\nCENTRALE", "INFERMERIA", "SALA\nMOTORI",
            "LABORATORIO\nBIOL.", "CORRIDOIO\nALLAGATO", "DEPOSITO\nTECNICO", "CAMERA\nDECOMPR.",
            "CONDOTTO\nAERAZ."
        };

        private final String[] nomiCompleti = {
            "Cabina di Comando", "Corridoio Centrale", "Infermeria", "Sala Motori",
            "Laboratorio Biologico", "Corridoio Allagato", "Deposito Tecnico", "Camera di Decompressione",
            "Condotto di Aerazione"
        };

        // CONNESSO IL LABORATORIO (4) AL CONDOTTO (8)
        private final int[][] connessioni = {
            {0, 1}, {1, 2}, {1, 3}, {1, 4}, {3, 5}, {5, 6}, {5, 7}, {4, 8}
        };

        public PannelloMappa(String stanzaCorrente) {
            this.stanzaCorrente = stanzaCorrente;
            setBackground(C_MAP_BOX);
        }

        public void aggiornaStanzaCorrente(String s) {
            stanzaCorrente = s; repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

            g2.setColor(C_MAP_BOX);
            g2.fillRect(0, 0, getWidth(), getHeight());

            g2.setColor(M_LINE);
            g2.setStroke(new BasicStroke(1.8f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            for (int[] c : connessioni) {
                int[] a = coord[c[0]], b = coord[c[1]];
                int ax = a[0]+a[2]/2, ay = a[1]+a[3]/2;
                int bx = b[0]+b[2]/2, by = b[1]+b[3]/2;
                g2.drawLine(ax, ay, bx, by);
            }

            for (int i = 0; i < coord.length; i++) {
                int x=coord[i][0], y=coord[i][1], w=coord[i][2], h=coord[i][3];
                boolean curr = nomiCompleti[i].equals(stanzaCorrente);
                boolean haEnigma = gioco.stanzaHaEnigma(nomiCompleti[i]) && !gioco.enigmaGiaRisolto(nomiCompleti[i]);

                Color bg = curr ? M_BOX_CUR : M_BOX_NRM;
                g2.setColor(bg);
                g2.fillRoundRect(x, y, w, h, 10, 10);

                GradientPaint gp = new GradientPaint(x, y, new Color(255,255,255, curr ? 20 : 10), x, y+h/2, new Color(0,0,0,0));
                g2.setPaint(gp);
                g2.fillRoundRect(x, y, w, h/2, 10, 10);

                Color brdCol = curr ? M_BRD_CUR : haEnigma ? M_ENIGMA : M_BRD_NRM;
                float brdW = curr ? 2.2f : haEnigma ? 1.6f : 1.0f;
                g2.setColor(brdCol);
                g2.setStroke(new BasicStroke(brdW));
                g2.drawRoundRect(x, y, w, h, 10, 10);

                Font font = new Font("Monospaced", Font.BOLD, curr ? 9 : 8);
                g2.setFont(font);
                g2.setColor(curr ? M_TXT_CUR : M_TXT_NRM);

                String[] righe = nomi[i].split("\n");
                int lh = font.getSize() + 3;
                int totH = righe.length * lh;
                int yS = y + (h - totH) / 2 + lh - 1;
                for (String r : righe) {
                    int tw = g2.getFontMetrics().stringWidth(r);
                    g2.drawString(r, x + (w - tw) / 2, yS);
                    yS += lh;
                }

                if (curr) {
                    g2.setColor(M_DOT);
                    g2.fillOval(x + w - 12, y + 4, 8, 8);
                    g2.setColor(new Color(0, 255, 100, 60));
                    g2.fillOval(x + w - 14, y + 2, 12, 12);
                }

                if (haEnigma && !curr) {
                    g2.setColor(M_ENIGMA);
                    g2.setFont(new Font("Monospaced", Font.BOLD, 9));
                    g2.drawString("?", x + w - 11, y + 13);
                }
            }

            int ly = getHeight() - 36;
            g2.setFont(new Font("Monospaced", Font.PLAIN, 9));
            g2.setColor(M_DOT);
            g2.fillOval(10, ly, 8, 8);
            g2.setColor(M_TXT_NRM);
            g2.drawString("posizione attuale", 24, ly + 8);

            g2.setColor(M_ENIGMA);
            g2.setFont(new Font("Monospaced", Font.BOLD, 9));
            g2.drawString("?", 10, ly + 24);
            g2.setFont(new Font("Monospaced", Font.PLAIN, 9));
            g2.setColor(M_TXT_NRM);
            g2.drawString("enigma disponibile", 24, ly + 24);
        }
    }
}