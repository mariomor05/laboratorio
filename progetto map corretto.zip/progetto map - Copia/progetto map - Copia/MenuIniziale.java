import javax.swing.*;
import java.awt.*;
import java.util.List;

public class MenuIniziale extends JFrame {
    
    public MenuIniziale() {
        DatabaseManager.inizializzaDatabase(); // Assicuriamoci che il DB esista
        
        setTitle("PROFONDITA' 3000 - Menu Principale");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Immagine di sfondo (assicurati di avere splash.jpg nella root del progetto)
        JLabel labelImmagine = new JLabel();
        try {
            ImageIcon icon = new ImageIcon("splash.jpg");
            Image img = icon.getImage().getScaledInstance(800, 400, Image.SCALE_SMOOTH);
            labelImmagine.setIcon(new ImageIcon(img));
        } catch (Exception e) {
            labelImmagine.setText("IMMAGINE NON TROVATA - INSERIRE splash.jpg");
            labelImmagine.setHorizontalAlignment(SwingConstants.CENTER);
            labelImmagine.setForeground(Color.RED);
        }
        labelImmagine.setPreferredSize(new Dimension(800, 400));
        add(labelImmagine, BorderLayout.NORTH);

        // Pannello bottoni
        JPanel pannelloBottoni = new JPanel(new GridLayout(3, 1, 10, 10));
        pannelloBottoni.setBorder(BorderFactory.createEmptyBorder(20, 200, 20, 200));
        pannelloBottoni.setBackground(new Color(8, 10, 18));

        JButton btnNuovaPartita = new JButton("NUOVA PARTITA");
        JButton btnCaricaPartita = new JButton("CARICA PARTITA");
        JButton btnEsci = new JButton("ESCI");

        btnNuovaPartita.addActionListener(e -> avviaNuovaPartita());
        btnCaricaPartita.addActionListener(e -> caricaPartitaEsistente());
        btnEsci.addActionListener(e -> System.exit(0));

        pannelloBottoni.add(btnNuovaPartita);
        pannelloBottoni.add(btnCaricaPartita);
        pannelloBottoni.add(btnEsci);

        add(pannelloBottoni, BorderLayout.CENTER);
        setVisible(true);
    }

    private void avviaNuovaPartita() {
        String[] opzioni = {"Facile (Lento)", "Normale (Standard)", "Difficile (Veloce)"};
        int scelta = JOptionPane.showOptionDialog(this, "Scegli il livello di difficoltà (influisce sul consumo di ossigeno nel tempo):",
                "Nuova Partita", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, opzioni, opzioni[1]);
        
        if (scelta != -1) {
            String difficolta = "Normale";
            if (scelta == 0) difficolta = "Facile";
            if (scelta == 2) difficolta = "Difficile";
            
            Gioco nuovoGioco = new Gioco(difficolta);
            new GameFrame(nuovoGioco); // Passiamo l'istanza al GameFrame
            this.dispose(); // Chiude il menu
        }
    }

    private void caricaPartitaEsistente() {
        List<String> slots = DatabaseManager.elencaSlot();
        if (slots.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nessun salvataggio presente nel Database.");
            return;
        }
        
        String[] arr = slots.toArray(new String[0]);
        String scelta = (String) JOptionPane.showInputDialog(this, "Scegli la partita da caricare:", 
                "Carica Partita", JOptionPane.PLAIN_MESSAGE, null, arr, arr[0]);
        
        if (scelta != null) {
            // Carica la mappa dei dati dal database
            java.util.Map<String, String> dati = DatabaseManager.caricaPartita(scelta);
            
            if (dati != null) {
                // Inizializza il gioco e passa i dati al metodo corretto
                Gioco giocoCaricato = new Gioco(dati.getOrDefault("difficolta", "Normale"));
                giocoCaricato.caricaDaFile(dati); 
                
                new GameFrame(giocoCaricato);
                this.dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Errore nel caricamento del salvataggio.");
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(MenuIniziale::new);
    }
}