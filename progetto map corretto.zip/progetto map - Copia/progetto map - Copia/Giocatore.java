import java.util.ArrayList; 

public class Giocatore {
    
    private Stanza stanzaCorrente; 
    private final ArrayList<Oggetto>inventario; 
    
    public Giocatore(Stanza stanzaIniziale) {
        this.stanzaCorrente = stanzaIniziale; 
        this.inventario = new ArrayList<>();
    }
    
    //per il movimento utilizzo le seguenti 
    public boolean muovi(String direzione) {
        Stanza prossima = stanzaCorrente.getUscita(direzione);
        if(prossima != null) {
            stanzaCorrente = prossima; 
            return true; 
        }
        return false; //direzione non valida
    }
    
    //per l'inventario invece utilizzo 
    public void aggiungiOggetto(Oggetto o, Object par1){
        inventario.add(o);
    }
    public void rimuoviOggetto(Oggetto o ){
        inventario.remove(o);
    }
    
    public boolean haOggetto(String nome){
        for(Oggetto o : inventario)
        if(o.getNome().equalsIgnoreCase(nome)) return true; 
           
        return false; 
    }
    public ArrayList<Oggetto> getInventario() {
        return inventario; 
    }
    public Stanza getStanzaCorrente() {
        return stanzaCorrente; 
    }
}