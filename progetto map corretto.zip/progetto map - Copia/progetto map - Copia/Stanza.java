import java.util.ArrayList;
import java.util.HashMap; 


public class Stanza {
    private String nome; 
    private String descrizione; 
    private HashMap<String,Stanza> uscite; 
    private ArrayList<Oggetto> oggetti; 
    
   public Stanza(String nome, String descrizione) {
       this.nome = nome; 
       this.descrizione = descrizione; 
       this.uscite = new HashMap<>();
       this.oggetti = new ArrayList<>();
   }
   
   //per le uscite all'interno di ogni stanza 
   
   public void setUscita(String direzione, Stanza stanza){
       uscite.put(direzione.toUpperCase(), stanza);
   }
   
   public HashMap<String, Stanza> getUscite(String direzione){
       return uscite; 
   }
   
   //per gli oggetti invece io devo poterli aggiungere 
   //qualora io entri in una stanza e toglierli se vi esco 
   
   public void addOggetto(Oggetto oggetto) {
       oggetti.add(oggetto);   
   }
   
   public void removeOggetto(Oggetto oggetto){
       oggetti.remove(oggetto);
   }
   
   
   public Stanza getUscita(String direzione) {
       return uscite.get(direzione.toUpperCase());
   }
   public ArrayList<Oggetto> getOggetto() {
       return oggetti; 
   }
   
   //per le info sulle stanze posso usare le seguenti
   
   public String getNome() {
       return nome; 
   }
   
   public String getDescrizione() {
       return descrizione; 
   }

   
}